# Kegel Pro 小米安卓版本

面向小米 Android 手机的男性盆底肌训练原型，使用 Kotlin、Jetpack Compose 和 Android TextToSpeech。

## 功能
- 中文界面
- 初级、中级、高级训练节奏
- 收缩与放松自动计时
- 中文语音提示（使用手机系统 TTS）
- 30 天循序渐进计划与训练日选择
- 本机保存完成次数和累计训练时长

## 在小米手机上安装
1. 在电脑安装 Android Studio。
2. 解压本项目，并用 Android Studio 打开项目根目录。
3. 等待 Gradle 同步；按提示安装 Android SDK 35。
4. 连接小米手机，开启开发者选项和 USB 调试。
5. 点击 Android Studio 的 Run 安装到手机。
6. 或选择 Build > Build Bundle(s) / APK(s) > Build APK(s) 生成 APK。

## 重要说明
此交付物是 Android Studio 项目源代码，不是已经编译、签名的 APK。当前原型尚未实现后台定时通知；语音提示在训练页面运行时播放。统计保存在本机应用偏好设置中。正式发布前还应进行真机测试、完善训练日历与数据备份。

训练请循序渐进，不要憋气或过度收缩。若出现疼痛或症状加重，应停止训练并咨询医疗专业人员。


## 无电脑云端编译（GitHub Actions）
1. 在手机浏览器登录 GitHub，创建一个新的空仓库。
2. 将本 ZIP 解压后，把项目内所有文件和隐藏目录 `.github` 上传到仓库根目录（注意保留目录结构）。
3. 确认默认分支为 `main`。进入仓库的 Actions 页面，选择 `Build Kegel Pro APK`，点击 `Run workflow`。
4. 等待工作流完成，打开本次运行记录，在 Artifacts 区域下载 `KegelPro-debug-apk`。
5. 解压下载的 artifact，得到 `app-debug.apk`，点击安装。若系统询问，允许浏览器/文件管理器安装此来源的应用。

这是用于个人测试的 debug APK，不是 Play 商店发布版。GitHub Actions 的界面名称可能随版本变化。不要公开上传个人密钥或敏感资料。
