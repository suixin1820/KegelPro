package com.example.kegelpro

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.util.Locale

private enum class Level(val title: String, val hold: Int, val rest: Int, val reps: Int) {
    BEGINNER("初级", 3, 6, 8),
    INTERMEDIATE("中级", 5, 5, 10),
    ADVANCED("高级", 6, 8, 10)
}

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var speaker: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        speaker = TextToSpeech(this, this)
        val prefs = getSharedPreferences("kegel_pro_stats", MODE_PRIVATE)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(
                primary = androidx.compose.ui.graphics.Color(0xFF176B5B),
                secondary = androidx.compose.ui.graphics.Color(0xFF4F8177)
            )) {
                KegelScreen(
                    savedSessions = prefs.getInt("sessions", 0),
                    savedSeconds = prefs.getInt("seconds", 0),
                    saveSession = { duration ->
                        prefs.edit()
                            .putInt("sessions", prefs.getInt("sessions", 0) + 1)
                            .putInt("seconds", prefs.getInt("seconds", 0) + duration)
                            .apply()
                    },
                    speak = { text ->
                        speaker?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kegel_voice")
                    }
                )
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            speaker?.language = Locale.SIMPLIFIED_CHINESE
        }
    }

    override fun onDestroy() {
        speaker?.stop()
        speaker?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun KegelScreen(
    savedSessions: Int,
    savedSeconds: Int,
    saveSession: (Int) -> Unit,
    speak: (String) -> Unit
) {
    var level by remember { mutableStateOf(Level.BEGINNER) }
    var day by remember { mutableIntStateOf(1) }
    var running by remember { mutableStateOf(false) }
    var contracting by remember { mutableStateOf(true) }
    var secondsLeft by remember { mutableIntStateOf(3) }
    var repsDone by remember { mutableIntStateOf(0) }
    var elapsed by remember { mutableIntStateOf(0) }
    var sessions by remember { mutableIntStateOf(savedSessions) }
    var totalSeconds by remember { mutableIntStateOf(savedSeconds) }

    LaunchedEffect(running, secondsLeft, contracting, level) {
        if (running) {
            delay(1000)
            elapsed += 1
            if (secondsLeft > 1) {
                secondsLeft -= 1
            } else if (contracting) {
                contracting = false
                secondsLeft = level.rest
                speak("放松，正常呼吸")
            } else {
                repsDone += 1
                if (repsDone >= level.reps) {
                    running = false
                    sessions += 1
                    totalSeconds += elapsed
                    saveSession(elapsed)
                    speak("训练完成，请充分放松")
                } else {
                    contracting = true
                    secondsLeft = level.hold
                    speak("轻轻收缩")
                }
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("KEGEL PRO", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        Text("男性盆底训练", style = MaterialTheme.typography.headlineMedium)
        Text("循序渐进 · 正确收缩 · 充分放松", style = MaterialTheme.typography.bodyMedium)

        Card {
            Column(
                Modifier.fillMaxWidth().padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("今日训练 · 第 $day 天", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(12.dp))
                Text(
                    if (!running) "准备开始" else if (contracting) "收缩盆底肌" else "放松盆底肌",
                    style = MaterialTheme.typography.headlineSmall
                )
                Text(
                    if (running) "${secondsLeft} 秒" else "—",
                    style = MaterialTheme.typography.displayLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Text("完成 ${repsDone.coerceAtMost(level.reps)} / ${level.reps} 次")
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = {
                        if (!running) {
                            repsDone = 0
                            elapsed = 0
                            contracting = true
                            secondsLeft = level.hold
                            running = true
                            speak("开始训练，轻轻收缩")
                        } else {
                            running = false
                            speak("训练暂停")
                        }
                    }) { Text(if (running) "暂停" else "开始训练") }
                    OutlinedButton(onClick = {
                        running = false
                        repsDone = 0
                        elapsed = 0
                        contracting = true
                        secondsLeft = level.hold
                    }) { Text("重置") }
                }
            }
        }

        Text("选择训练等级", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Level.values().forEach { item ->
                FilterChip(
                    selected = level == item,
                    onClick = {
                        running = false
                        level = item
                        repsDone = 0
                        contracting = true
                        secondsLeft = item.hold
                    },
                    label = { Text(item.title) }
                )
            }
        }
        Text("${level.hold}秒收缩 · ${level.rest}秒放松 · ${level.reps}次循环")

        Card {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                Text("30天循序渐进计划", style = MaterialTheme.typography.titleMedium)
                Text("第1–7天：初级；第8–14天：初级巩固；第15–21天：中级；第22–30天：按舒适程度选择中级。")
                Spacer(Modifier.height(8.dp))
                Text("当前计划：第 $day 天")
                Slider(
                    value = day.toFloat(),
                    onValueChange = { day = it.toInt().coerceIn(1, 30) },
                    valueRange = 1f..30f,
                    steps = 28
                )
            }
        }

        Text("训练统计", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("完成训练", "$sessions 次", Modifier.weight(1f))
            StatTile("累计训练", "${totalSeconds / 60} 分钟", Modifier.weight(1f))
        }

        Card {
            Column(Modifier.padding(16.dp)) {
                Text("训练安全提示", style = MaterialTheme.typography.titleMedium)
                Text(
                    "• 保持自然呼吸，不要憋气。\n" +
                    "• 不要夹紧臀部、大腿或腹部。\n" +
                    "• 放松阶段要完全放松。\n" +
                    "• 不要经常通过中断尿流来练习。\n" +
                    "• 若出现会阴疼痛、尿急加重或持续紧绷，请暂停并咨询专业人员。"
                )
            }
        }
        Text(
            "提示：本应用用于一般训练记录，不用于诊断或治疗勃起功能障碍。",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun StatTile(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.bodySmall)
            Text(value, style = MaterialTheme.typography.titleLarge)
        }
    }
}
